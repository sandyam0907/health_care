<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-17 05:25:03 --> 404 Page Not Found: Assets/dist
