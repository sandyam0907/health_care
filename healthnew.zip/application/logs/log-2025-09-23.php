<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-23 07:48:32 --> 404 Page Not Found: Assets/dist
ERROR - 2025-09-23 12:43:20 --> 404 Page Not Found: Assets/dist
ERROR - 2025-09-23 13:31:20 --> 404 Page Not Found: Assets/dist
