<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-02-19 04:11:31 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 04:15:59 --> 404 Page Not Found: Plugins/iCheck
ERROR - 2026-02-19 04:16:09 --> 404 Page Not Found: admin/Mailbox/compose.html
ERROR - 2026-02-19 04:28:44 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 07:46:18 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 07:46:36 --> 404 Page Not Found: Public/bootstrap
ERROR - 2026-02-19 07:54:03 --> 404 Page Not Found: user//index
ERROR - 2026-02-19 07:55:32 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 07:56:34 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 08:01:32 --> 404 Page Not Found: Dist/css
ERROR - 2026-02-19 08:01:44 --> 404 Page Not Found: Dist/css
ERROR - 2026-02-19 08:02:04 --> 404 Page Not Found: Dist/css
ERROR - 2026-02-19 08:02:26 --> 404 Page Not Found: Dist/css
ERROR - 2026-02-19 08:02:46 --> 404 Page Not Found: Asset/dist
ERROR - 2026-02-19 08:02:49 --> 404 Page Not Found: Asset/dist
ERROR - 2026-02-19 08:08:17 --> 404 Page Not Found: user/Auth/index.html
ERROR - 2026-02-19 08:10:07 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 08:21:59 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 08:23:38 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 08:23:44 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 08:27:06 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 08:27:08 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 08:28:04 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 08:28:06 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 08:28:21 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 08:28:24 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 08:28:33 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 08:28:39 --> 404 Page Not Found: user/Dashboard/index
ERROR - 2026-02-19 13:23:52 --> 404 Page Not Found: user/Dashboard/index
ERROR - 2026-02-19 13:24:57 --> 404 Page Not Found: user/Auth/dashboard
ERROR - 2026-02-19 13:26:00 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:36:44 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 02:36:53 --> Severity: Notice --> Undefined index: admin_id C:\xampp\htdocs\health\application\controllers\user\Auth.php 57
ERROR - 2026-02-19 02:36:53 --> Severity: Notice --> Undefined index: admin_role_id C:\xampp\htdocs\health\application\controllers\user\Auth.php 59
ERROR - 2026-02-19 02:36:53 --> Severity: Notice --> Undefined index: admin_role_title C:\xampp\htdocs\health\application\controllers\user\Auth.php 60
ERROR - 2026-02-19 02:36:53 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\health\application\controllers\user\Auth.php 61
ERROR - 2026-02-19 02:36:53 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\health\application\controllers\user\Auth.php 67
ERROR - 2026-02-19 02:36:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Dashboard_model C:\xampp\htdocs\health\system\core\Loader.php 348
ERROR - 2026-02-19 02:39:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Dashboard_model C:\xampp\htdocs\health\system\core\Loader.php 348
ERROR - 2026-02-19 13:39:48 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:48:29 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\health\application\controllers\user\Auth.php 15
ERROR - 2026-02-19 13:48:34 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:48:52 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:48:57 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:48:57 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:48:58 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:48:58 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:48:58 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:48:59 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:48:59 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:48:59 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:48:59 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:49:00 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:49:06 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 02:49:13 --> Severity: Notice --> Undefined index: admin_id C:\xampp\htdocs\health\application\controllers\user\Auth.php 58
ERROR - 2026-02-19 02:49:13 --> Severity: Notice --> Undefined index: admin_role_id C:\xampp\htdocs\health\application\controllers\user\Auth.php 60
ERROR - 2026-02-19 02:49:13 --> Severity: Notice --> Undefined index: admin_role_title C:\xampp\htdocs\health\application\controllers\user\Auth.php 61
ERROR - 2026-02-19 02:49:13 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\health\application\controllers\user\Auth.php 62
ERROR - 2026-02-19 02:53:48 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\health\application\controllers\user\Auth.php 68
ERROR - 2026-02-19 13:54:19 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:54:22 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 02:54:36 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\health\application\controllers\user\Auth.php 68
ERROR - 2026-02-19 13:55:21 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 02:57:01 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\health\application\controllers\user\Auth.php 68
ERROR - 2026-02-19 13:57:06 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 13:57:16 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 02:57:26 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\health\application\controllers\user\Auth.php 69
ERROR - 2026-02-19 13:57:52 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:00:54 --> 404 Page Not Found: user/New_screeninghtml/index
ERROR - 2026-02-19 14:05:13 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:06:06 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:06:08 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:07:12 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:07:13 --> 404 Page Not Found: user/New_screening/index
ERROR - 2026-02-19 14:08:54 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:09:47 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:10:15 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:10:35 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:10:51 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:12:08 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:12:21 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:12:28 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:13:51 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:14:28 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-19 14:14:28 --> 404 Page Not Found: Assets/dist
