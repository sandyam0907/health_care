<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-08 08:59:34 --> 404 Page Not Found: Assets/dist
ERROR - 2025-09-08 09:01:04 --> 404 Page Not Found: Dist/img
