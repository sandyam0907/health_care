<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-12 08:27:33 --> 404 Page Not Found: Assets/dist
