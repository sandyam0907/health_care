<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-02-18 17:21:20 --> Query error: Table 'health.users' doesn't exist - Invalid query: INSERT INTO `users` (`username`, `firstname`, `lastname`, `email`, `mobile_no`, `address`, `password`, `created_at`, `updated_at`) VALUES ('sandhya', 'sandhya', 'm', 'sandyam0907@gmail.com', '9876543213', 'test', '$2y$10$ngOQSzjMpr0DHXLLq57JiOH6KizF8iwfSL1X5CZGAqH/JGrMi4d1y', '2026-02-18 : 05:02:20', '2026-02-18 : 05:02:20')
ERROR - 2026-02-18 20:54:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Auth_model C:\xampp\htdocs\health\system\core\Loader.php 348
ERROR - 2026-02-18 21:28:39 --> Severity: Notice --> Undefined index: admin_id C:\xampp\htdocs\health\application\controllers\user\Auth.php 57
ERROR - 2026-02-18 21:28:39 --> Severity: Notice --> Undefined index: admin_role_id C:\xampp\htdocs\health\application\controllers\user\Auth.php 59
ERROR - 2026-02-18 21:28:39 --> Severity: Notice --> Undefined index: admin_role_title C:\xampp\htdocs\health\application\controllers\user\Auth.php 60
ERROR - 2026-02-18 21:28:39 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\health\application\controllers\user\Auth.php 61
ERROR - 2026-02-18 21:28:39 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\health\application\controllers\user\Auth.php 67
