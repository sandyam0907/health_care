<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-27 02:01:31 --> 404 Page Not Found: Assets/dist
