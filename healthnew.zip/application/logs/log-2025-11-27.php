<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-27 16:31:28 --> 404 Page Not Found: Assets/dist
