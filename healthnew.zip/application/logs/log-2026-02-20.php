<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-02-20 03:02:28 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\health\application\controllers\user\Auth.php 68
ERROR - 2026-02-20 14:03:13 --> 404 Page Not Found: user/Report/index
ERROR - 2026-02-20 03:25:50 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 94
ERROR - 2026-02-20 03:25:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 94
ERROR - 2026-02-20 03:26:52 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 94
ERROR - 2026-02-20 03:26:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 94
ERROR - 2026-02-20 03:27:39 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 94
ERROR - 2026-02-20 03:27:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 94
ERROR - 2026-02-20 03:28:21 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 94
ERROR - 2026-02-20 03:28:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 94
ERROR - 2026-02-20 03:28:47 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 94
ERROR - 2026-02-20 03:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 94
ERROR - 2026-02-20 03:29:23 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-20 03:29:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-20 03:29:32 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-20 03:29:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-20 03:30:25 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-20 03:30:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-20 03:30:41 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-20 03:30:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-20 03:38:52 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-20 03:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-20 03:39:44 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-20 03:39:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-20 03:42:14 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-20 03:42:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 93
