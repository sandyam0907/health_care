<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-21 07:24:48 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-21 07:25:11 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-21 07:25:11 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-21 07:26:27 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-21 07:26:33 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-21 07:37:46 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-21 07:46:34 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-21 09:15:48 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-21 09:15:58 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-21 09:26:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:26:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:26:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:26:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:26:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:26:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:28:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:28:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:28:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:28:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:28:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:28:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:31:10 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:31:10 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:31:10 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:31:10 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:31:10 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:31:10 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:31:13 --> 404 Page Not Found: admin/State/index
ERROR - 2019-11-21 09:31:58 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:31:58 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:31:58 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:31:58 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:31:58 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:32:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:32:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:32:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:32:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:32:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:32:07 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:32:07 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:32:07 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:32:07 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:32:07 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:33:30 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:33:30 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:33:30 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:33:31 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:33:31 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:33:31 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:42:44 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:42:44 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:48:30 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:48:30 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:48:30 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:48:30 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 09:48:30 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 10:27:26 --> 404 Page Not Found: admin/Location/add
ERROR - 2019-11-21 10:41:22 --> 404 Page Not Found: admin/Language/index
ERROR - 2019-11-21 10:46:26 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 10:46:26 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 10:46:26 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 10:47:45 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 10:47:45 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 10:47:45 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 10:47:45 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 10:49:52 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 10:49:52 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 10:49:53 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 10:49:53 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-21 00:03:43 --> Severity: Notice --> Undefined variable: data F:\xampp\htdocs\ozient\adminlite\application\controllers\admin\Languages.php 25
ERROR - 2019-11-21 00:03:43 --> Severity: Notice --> Undefined variable: data F:\xampp\htdocs\ozient\adminlite\application\controllers\admin\Languages.php 26
ERROR - 2019-11-21 20:28:35 --> Query error: Unknown column 'display_name' in 'field list' - Invalid query: INSERT INTO `ci_language` (`display_name`, `directory_name`) VALUES ('', '')
ERROR - 2019-11-21 20:29:01 --> Query error: Unknown column 'short_name' in 'field list' - Invalid query: INSERT INTO `ci_language` (`name`, `short_name`) VALUES ('Urdu', 'UR')
ERROR - 2019-11-21 20:31:14 --> Severity: Notice --> Undefined index: display_name F:\xampp\htdocs\ozient\adminlite\application\views\admin\language\language_edit.php 39
ERROR - 2019-11-21 20:31:14 --> Severity: Notice --> Undefined index: directory_name F:\xampp\htdocs\ozient\adminlite\application\views\admin\language\language_edit.php 47
ERROR - 2019-11-21 20:31:37 --> Severity: Notice --> Undefined index: display_name F:\xampp\htdocs\ozient\adminlite\application\views\admin\language\language_edit.php 40
ERROR - 2019-11-21 20:31:37 --> Severity: Notice --> Undefined index: directory_name F:\xampp\htdocs\ozient\adminlite\application\views\admin\language\language_edit.php 48
ERROR - 2019-11-21 20:31:47 --> Severity: Notice --> Undefined index: display_name F:\xampp\htdocs\ozient\adminlite\application\views\admin\language\language_edit.php 40
ERROR - 2019-11-21 20:31:47 --> Severity: Notice --> Undefined index: directory_name F:\xampp\htdocs\ozient\adminlite\application\views\admin\language\language_edit.php 48
ERROR - 2019-11-21 20:35:02 --> Severity: Notice --> Undefined index: short_nae F:\xampp\htdocs\ozient\adminlite\application\views\admin\language\language_edit.php 26
ERROR - 2019-11-21 20:49:18 --> Severity: error --> Exception: Call to undefined method Admin_roles_model::get_all_module() F:\xampp\htdocs\ozient\adminlite\application\controllers\admin\Admin_roles.php 122
ERROR - 2019-11-21 20:50:56 --> Query error: Table 'ci_roles_permissions.ci_module' doesn't exist - Invalid query: SELECT *
FROM `ci_module`
ERROR - 2019-11-21 20:51:13 --> Severity: Error --> Class 'Model' not found F:\xampp\htdocs\ozient\adminlite\application\models\admin\Admin_roles_model.php 2
ERROR - 2019-11-21 20:59:59 --> Severity: error --> Exception: syntax error, unexpected end of file F:\xampp\htdocs\ozient\adminlite\application\views\admin\includes\_sidebar.php 601
ERROR - 2019-11-21 21:01:05 --> Query error: Table 'ci_roles_permissions.ci_module' doesn't exist - Invalid query: SELECT *
FROM `ci_module`
ORDER BY `sort_order` ASC
ERROR - 2019-11-21 21:01:17 --> Severity: error --> Exception: Call to undefined function get_sidebar_sub_menu() F:\xampp\htdocs\ozient\adminlite\application\views\admin\includes\_sidebar.php 67
ERROR - 2019-11-21 21:02:01 --> Query error: Table 'ci_roles_permissions.sub_module' doesn't exist - Invalid query: SELECT *
FROM `sub_module`
WHERE `parent` = '1'
ORDER BY `sort_order` ASC
ERROR - 2019-11-21 21:03:16 --> Query error: Table 'ci_roles_permissions.sub_module' doesn't exist - Invalid query: SELECT *
FROM `sub_module`
WHERE `parent` = '1'
ORDER BY `sort_order` ASC
ERROR - 2019-11-21 21:08:10 --> Query error: Table 'ci_roles_permissions.sub_module' doesn't exist - Invalid query: SELECT *
FROM `sub_module`
WHERE `parent` = '1'
ORDER BY `sort_order` ASC
ERROR - 2019-11-21 21:10:55 --> Query error: Table 'ci_roles_permissions.sub_module' doesn't exist - Invalid query: SELECT *
FROM `sub_module`
WHERE `parent` = '1'
ORDER BY `sort_order` ASC
ERROR - 2019-11-21 21:10:56 --> Query error: Table 'ci_roles_permissions.sub_module' doesn't exist - Invalid query: SELECT *
FROM `sub_module`
WHERE `parent` = '1'
ORDER BY `sort_order` ASC
ERROR - 2019-11-21 21:11:00 --> Query error: Table 'ci_roles_permissions.sub_module' doesn't exist - Invalid query: SELECT *
FROM `sub_module`
WHERE `parent` = '1'
ORDER BY `sort_order` ASC
ERROR - 2019-11-21 21:11:47 --> Query error: Table 'ci_roles_permissions.sub_module' doesn't exist - Invalid query: SELECT *
FROM `sub_module`
WHERE `parent` = '1'
ORDER BY `sort_order` ASC
ERROR - 2019-11-21 21:11:49 --> Query error: Table 'ci_roles_permissions.sub_module' doesn't exist - Invalid query: SELECT *
FROM `sub_module`
WHERE `parent` = '1'
ORDER BY `sort_order` ASC
