<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-02-16 09:01:20 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-16 09:08:18 --> 404 Page Not Found: Public/plugins
ERROR - 2026-02-16 09:08:18 --> 404 Page Not Found: Public/plugins
ERROR - 2026-02-16 09:23:39 --> 404 Page Not Found: admin/Roles/index
ERROR - 2026-02-16 10:19:35 --> 404 Page Not Found: Assets/dist
