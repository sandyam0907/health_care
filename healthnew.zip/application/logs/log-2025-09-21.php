<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-21 19:48:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\adminlite\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2025-09-21 19:48:58 --> Unable to connect to the database
ERROR - 2025-09-21 20:02:30 --> 404 Page Not Found: Assets/dist
ERROR - 2025-09-21 20:41:58 --> 404 Page Not Found: Assets/dist
ERROR - 2025-09-21 20:43:31 --> 404 Page Not Found: Assets/dist
ERROR - 2025-09-21 20:54:41 --> 404 Page Not Found: Assets/dist
ERROR - 2025-09-21 21:04:28 --> 404 Page Not Found: Assets/dist
ERROR - 2025-09-21 21:04:29 --> 404 Page Not Found: admin/Auth/forget_password
ERROR - 2025-09-21 10:04:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\adminlite\application\helpers\functions_helper.php 90
ERROR - 2025-09-21 10:04:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\adminlite\application\helpers\functions_helper.php 90
ERROR - 2025-09-21 10:04:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\adminlite\application\helpers\functions_helper.php 90
ERROR - 2025-09-21 10:04:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\adminlite\application\helpers\functions_helper.php 90
