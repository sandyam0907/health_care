<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-25 08:42:08 --> 404 Page Not Found: Assets/dist
