<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-12-12 08:54:42 --> 404 Page Not Found: Assets/dist
ERROR - 2025-12-12 08:55:26 --> 404 Page Not Found: Public/plugins
ERROR - 2025-12-12 08:55:26 --> 404 Page Not Found: Public/plugins
ERROR - 2025-12-12 08:57:53 --> 404 Page Not Found: Assets/dist
ERROR - 2025-12-12 08:59:28 --> 404 Page Not Found: Dist/img
ERROR - 2025-12-12 08:59:46 --> 404 Page Not Found: Public/bootstrap
ERROR - 2025-12-12 08:59:58 --> 404 Page Not Found: Dist/img
ERROR - 2025-12-12 09:00:08 --> 404 Page Not Found: admin/Role/index
ERROR - 2025-12-12 09:00:11 --> 404 Page Not Found: admin/Roles/index
