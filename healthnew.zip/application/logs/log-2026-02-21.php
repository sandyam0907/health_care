<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-02-21 22:52:46 --> Severity: Notice --> Undefined index: is_supper C:\xampp\htdocs\health\application\controllers\user\Auth.php 68
ERROR - 2026-02-21 22:53:46 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-21 22:53:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 93
ERROR - 2026-02-21 23:06:02 --> Severity: Notice --> Undefined variable: states C:\xampp\htdocs\health\application\views\user\new_screening.php 64
ERROR - 2026-02-21 23:06:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 64
ERROR - 2026-02-21 23:06:02 --> Severity: Notice --> Undefined variable: districts C:\xampp\htdocs\health\application\views\user\new_screening.php 73
ERROR - 2026-02-21 23:06:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 73
ERROR - 2026-02-21 23:06:02 --> Severity: Notice --> Undefined variable: taluks C:\xampp\htdocs\health\application\views\user\new_screening.php 89
ERROR - 2026-02-21 23:06:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 89
ERROR - 2026-02-21 23:06:02 --> Severity: Notice --> Undefined variable: users C:\xampp\htdocs\health\application\views\user\new_screening.php 133
ERROR - 2026-02-21 23:06:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 133
ERROR - 2026-02-21 23:06:02 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 180
ERROR - 2026-02-21 23:06:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 180
ERROR - 2026-02-21 23:07:06 --> Severity: Notice --> Undefined variable: states C:\xampp\htdocs\health\application\views\user\new_screening.php 64
ERROR - 2026-02-21 23:07:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 64
ERROR - 2026-02-21 23:07:06 --> Severity: Notice --> Undefined variable: districts C:\xampp\htdocs\health\application\views\user\new_screening.php 73
ERROR - 2026-02-21 23:07:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 73
ERROR - 2026-02-21 23:07:06 --> Severity: Notice --> Undefined variable: taluks C:\xampp\htdocs\health\application\views\user\new_screening.php 89
ERROR - 2026-02-21 23:07:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 89
ERROR - 2026-02-21 23:07:06 --> Severity: Notice --> Undefined variable: users C:\xampp\htdocs\health\application\views\user\new_screening.php 133
ERROR - 2026-02-21 23:07:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 133
ERROR - 2026-02-21 23:07:06 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 180
ERROR - 2026-02-21 23:07:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 180
ERROR - 2026-02-21 23:07:43 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 180
ERROR - 2026-02-21 23:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 180
ERROR - 2026-02-21 23:09:05 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 177
ERROR - 2026-02-21 23:09:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 177
ERROR - 2026-02-21 23:09:55 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 181
ERROR - 2026-02-21 23:09:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 181
ERROR - 2026-02-21 23:12:03 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:13:11 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:13:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:13:48 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:13:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:14:33 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:14:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:15:08 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:15:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:15:38 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:15:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:16:05 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:17:18 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:17:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:18:07 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:18:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:18:40 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:18:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:18:58 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:18:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:19:34 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:19:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:21:19 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:21:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:22:16 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:22:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:24:06 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:24:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:24:25 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:24:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:24:54 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:24:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:25:33 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:25:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:25:46 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:25:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:26:47 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:27:10 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:27:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:27:23 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:27:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:28:01 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:28:21 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:28:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:29:28 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:29:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:31:42 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:31:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:32:46 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:32:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:33:12 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:33:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:35:20 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:35:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:36:21 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:36:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:36:43 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:36:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:36:52 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:36:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:37:07 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:37:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:39:38 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:39:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 173
ERROR - 2026-02-21 23:40:51 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-21 23:40:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-21 23:41:59 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-21 23:41:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-21 23:42:01 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-21 23:42:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-21 23:42:30 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-21 23:42:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 186
