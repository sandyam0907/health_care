<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-24 04:07:50 --> 404 Page Not Found: Assets/dist
ERROR - 2025-09-24 08:54:23 --> 404 Page Not Found: Assets/dist
ERROR - 2025-09-24 09:35:10 --> 404 Page Not Found: Assets/dist
ERROR - 2025-09-24 13:53:20 --> 404 Page Not Found: Assets/dist
