<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-30 10:07:55 --> 404 Page Not Found: Assets/dist
