<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-02-22 10:12:26 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-22 10:12:26 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-22 10:13:11 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-22 10:13:11 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-22 10:25:59 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-22 10:25:59 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-22 10:26:47 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-22 10:26:47 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-22 10:27:10 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-22 10:27:10 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-22 10:27:24 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-22 10:27:24 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-22 20:04:16 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:04:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:04:41 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:04:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:07:03 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:07:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:10:00 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:10:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:11:38 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:11:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:12:04 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:12:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:12:30 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:12:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:12:49 --> Severity: Notice --> Undefined variable: patients C:\xampp\htdocs\health\application\views\user\new_screening.php 186
ERROR - 2026-02-22 20:12:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\health\application\views\user\new_screening.php 186
