<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2026-02-23 13:20:18 --> 404 Page Not Found: user/Loginhtml/index
ERROR - 2026-02-23 13:20:24 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-23 13:22:57 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-23 13:23:21 --> 404 Page Not Found: Assets/dist
ERROR - 2026-02-23 13:26:22 --> 404 Page Not Found: Assets/dist
