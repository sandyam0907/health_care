<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-10 20:52:12 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-10 21:07:54 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-10 21:07:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2020-01-10 21:08:23 --> 404 Page Not Found: Public/bootstrap
ERROR - 2020-01-10 21:11:48 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-10 21:13:30 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-10 21:19:11 --> 404 Page Not Found: Assets/dist
ERROR - 2020-01-10 10:19:29 --> Severity: Notice --> Undefined index: data F:\xampp\htdocs\ozient\adminlite\application\controllers\admin\Example.php 116
ERROR - 2020-01-10 10:19:29 --> Severity: Warning --> Invalid argument supplied for foreach() F:\xampp\htdocs\ozient\adminlite\application\controllers\admin\Example.php 116
ERROR - 2020-01-10 10:20:09 --> Severity: Notice --> Undefined index: data F:\xampp\htdocs\ozient\adminlite\application\controllers\admin\Example.php 116
ERROR - 2020-01-10 10:20:09 --> Severity: Warning --> Invalid argument supplied for foreach() F:\xampp\htdocs\ozient\adminlite\application\controllers\admin\Example.php 116
ERROR - 2020-01-10 10:26:38 --> Severity: Notice --> Undefined index: data F:\xampp\htdocs\ozient\adminlite\application\controllers\admin\Joins.php 29
ERROR - 2020-01-10 10:26:38 --> Severity: Warning --> Invalid argument supplied for foreach() F:\xampp\htdocs\ozient\adminlite\application\controllers\admin\Joins.php 29
