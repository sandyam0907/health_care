<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-30 10:14:23 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-30 15:31:00 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-30 15:31:17 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-30 15:31:20 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-30 15:31:22 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-30 15:31:24 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-30 15:31:27 --> 404 Page Not Found: Assets/dist
ERROR - 2019-11-30 15:38:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 15:38:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 15:38:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 15:38:25 --> 404 Page Not Found: Public/plugins
