<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-09-02 07:56:49 --> 404 Page Not Found: Auth/admin
ERROR - 2025-09-02 07:58:49 --> 404 Page Not Found: Auth/login
ERROR - 2025-09-02 07:59:01 --> 404 Page Not Found: Auth/login
ERROR - 2025-09-02 07:59:06 --> 404 Page Not Found: Assets/dist
ERROR - 2025-09-02 08:00:36 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\adminlite\system\core\Common.php 597
ERROR - 2025-09-02 08:01:54 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\adminlite\system\core\Common.php 597
ERROR - 2025-09-02 08:02:13 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\adminlite\system\core\Common.php 597
